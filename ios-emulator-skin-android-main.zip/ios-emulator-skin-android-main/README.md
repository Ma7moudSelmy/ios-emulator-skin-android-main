# ios-emulator-skin-android
An ios emulator skin for android studio useful for flutter and react native developers
tutorial link : https://youtu.be/QHF_FWMHQFQ?si=ukKpP_g6Lsj9TZP5
